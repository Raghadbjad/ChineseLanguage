//
//  Test.swift
//  ChineseLanguage
//
//  Created by Raghad on 03/04/1446 AH.
//

import SwiftUI
import  AVFoundation
struct Test: View {
    @State private var showPravoImage = false
    @State private var shakeEffect1 = false
    @State private var shakeEffect2 = false
    @State private var showRightAnswer = false
    @State private var navigateToNextQuestion = false
//    @State private var audioPlayer: AVAudioPlayer?
    var body: some View {
        NavigationStack {
            ZStack {
                Color("AccentColor").ignoresSafeArea()
                
                VStack {
                    Text("ما هي الإجابة الصحيحة للرقم إثنان ؟")
                        .fontWeight(.bold)
                        .foregroundColor(Color.black)
                        .font(.custom("Helvetica Neue", size: 20))
                        .padding(.bottom , 80)
                    HStack {
                        Button(action: {
                            shakeEffect1 = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                shakeEffect1 = false
                            }
                        }) {
                            Image("num2")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 120, height: 120)
                                .clipShape(Circle())
                                .padding()
                        }
                        .offset(x: shakeEffect1 ? -10 : 0)
                        .animation(Animation.default.repeatCount(5).speed(5), value: shakeEffect1)

                        Button(action: {
                            shakeEffect2 = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                shakeEffect2 = false
                            }
                        }) {
                            Image("num1")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 120, height: 120)
                                .clipShape(Circle())
                                .padding()
                        }
                        .offset(x: shakeEffect2 ? -10 : 0)
                        .animation(Animation.default.repeatCount(5).speed(5), value: shakeEffect2)
                    }

                    Button(action: {
                        withAnimation {
                            showPravoImage = true
                            showRightAnswer = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                                navigateToNextQuestion = true
                            }
                        }
                    }) {
                        Image("RightAnswer")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 120)
                            .clipShape(Circle())
                            .padding()
                    }
                }
                .padding(.bottom, 10)
                        
                if showRightAnswer {
                    Image("Pravo1")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 300, height: 300)
                        .transition(.scale)
                        .animation(.easeInOut)
                }
                
           Image("Palm")
                .resizable()
                .scaledToFit()
                .frame(width: 410, height: 220)
                .padding(.top, 633)
            }
            .navigationDestination(isPresented: $navigateToNextQuestion) {
                NextQuestionView()
            }
        }
    }
//    private func playSound() {
//        guard let url = Bundle.main.url(forResource: "Num1", withExtension: "mp3") else {
//            print("ملف الصوت غير موجود")
//            return
//        }
//        
//        do {
//            audioPlayer = try AVAudioPlayer(contentsOf: url)
//            audioPlayer?.play() // تشغيل الصوت
//        } catch {
//            print("خطأ في تشغيل الصوت: \(error)")
//        }
//    }
}

#Preview ("Test") {
    Test()
}
    
    


struct NextQuestionView: View {
    @State private var showPravoImage = false
    @State private var shakeEffect1 = false
    @State private var shakeEffect2 = false
    @State private var showRightAnswer = false
    @State private var navigateToNextQuestion = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color("AccentColor").ignoresSafeArea()
                
                VStack {
                    Text("هل هذا الرمز يدل على كلمة أنا ؟ ")
                        .foregroundColor(Color.black)
                        .fontWeight(.bold)
                        .font(.custom("Helvetica Neue", size: 20))
                    
                    Image("SignMe")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 120, height: 120)
                    
                        .padding()
                    
                    HStack {
                        Button(action: {
                            shakeEffect2 = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                shakeEffect2 = false
                            }
                        }) {
                            Image("No")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 120, height: 120)
                                .clipShape(Circle())
                                .padding()
                        }
                        .offset(x: shakeEffect2 ? -10 : 0)
                        .animation(Animation.default.repeatCount(5).speed(5), value: shakeEffect2)
                        
                        
                        Button(action: {
                            withAnimation {
                                showPravoImage = true
                                showRightAnswer = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                                    navigateToNextQuestion = true
                                }
                            }
                        }) {
                            Image("Yes")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 120, height: 120)
                                .clipShape(Circle())
                                .padding()
                        }
                    }
                }
                    .padding(.top)
                
                if showRightAnswer {
                    Image("Pravo2")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 300, height: 300)
                        .transition(.scale)
                        .animation(.easeInOut)
                }
                
           Image("Palm")
                .resizable()
                .scaledToFit()
                .frame(width: 410, height: 220)
//                .padding(.top, 648.0)
                .padding(.top, 598)
            }
            .navigationDestination(isPresented: $navigateToNextQuestion) {
                NextQuestionView1()
            }
        }
    }
}



#Preview ("NextQuestionView") {
    NextQuestionView()
}

struct NextQuestionView1: View {
    @State private var showPravoImage = false
    @State private var shakeEffect1 = false
    @State private var shakeEffect2 = false
    @State private var showRightAnswer = false
    @State private var navigateToNextQuestion = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color("AccentColor").ignoresSafeArea()
                
                VStack {
                    Text("على ماذا يدل هذا الرمز ؟")
                    
                        .fontWeight(.bold)
                        .foregroundColor(Color.black)
                        .font(.custom("Helvetica Neue", size: 20))
                    
                    Image("Num3")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 120, height: 120)
                        .padding()
                    
                    HStack {
                        Button(action: {
                            shakeEffect1 = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                shakeEffect1 = false
                            }
                        }) {
                            Image("Group17")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 120, height: 120)
                                .clipShape(Circle())
                                .padding()
                        }
                        .offset(x: shakeEffect1 ? -10 : 0)
                        .animation(Animation.default.repeatCount(5).speed(5), value: shakeEffect1)

                        Button(action: {
                            shakeEffect2 = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                shakeEffect2 = false
                            }
                        }) {
                            Image("Group16")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 120, height: 120)
                                .clipShape(Circle())
                                .padding()
                        }
                        .offset(x: shakeEffect2 ? -10 : 0)
                        .animation(Animation.default.repeatCount(5).speed(5), value: shakeEffect2)
                    }

                    Button(action: {
                        withAnimation {
                            showPravoImage = true
                            showRightAnswer = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                                navigateToNextQuestion = true
                            }
                        }
                    }) {
                        Image("Group15")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 120)
                            .clipShape(Circle())
                            .padding(.bottom , 200)
                    }
                }
                .padding(.top, 250)

                if showRightAnswer {
                    Image("Pravo2")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 300, height: 300)
                        .transition(.scale)
                        .animation(.easeInOut)
                }
                
           Image("Palm")
                .resizable()
                .scaledToFit()
                .frame(width: 410, height: 220)
//                .padding(.top, 648.0)
                .padding(.top, 598)
                
            }
            .navigationDestination(isPresented: $navigateToNextQuestion) {
                NextQuestionView2()
            }
        }
    }
}

#Preview("3"){
    NextQuestionView1()
    
}

struct NextQuestionView2: View {
    @State private var showPravoImage = false
    @State private var shakeEffect1 = false
    @State private var shakeEffect2 = false
    @State private var showRightAnswer = false
    @State private var navigateToNextQuestion = false
    @AppStorage("userPassedLevel1") private var userPassedLevel1: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color("AccentColor").ignoresSafeArea()
                
                VStack {
                    Text("هل هذا الرمز يدل على كلمة أنا ؟ ")
                        .fontWeight(.bold)
                        .foregroundColor(Color.black)
                        .font(.custom("Helvetica Neue", size: 20))
                        .padding()
                    
                    Image("Sunday")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 120, height: 120)
                        .padding()
                    
                    HStack {
                        Button(action: {
                            shakeEffect2 = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                shakeEffect2 = false
                            }
                        }) {
                            Image("YesRed")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 120, height: 120)
                                .clipShape(Circle())
                                .padding()
                        }
                        .offset(x: shakeEffect2 ? -10 : 0)
                        .animation(Animation.default.repeatCount(6).speed(2), value: shakeEffect2)
                        
                        Button(action: {
                            withAnimation {
                                userPassedLevel1 = true
                                showRightAnswer = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                    navigateToNextQuestion = true
                                }
                            }
                        }) {
                            Image("NoRed")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 120, height: 120)
                                .clipShape(Circle())
                                .padding()
                        }
                    }
                }
                .padding(.top)
                
                if showRightAnswer {
                    Image("Pravo3")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 300, height: 300)
                        .transition(.scale)
                        .animation(.easeInOut)
                        .onAppear {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                showRightAnswer = false
                            }
                        }
                }
                
                Image("Palm")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 410, height: 220)
//                    .padding(.top, 648.0)
                    .padding(.top, 598)
            }
            .navigationDestination(isPresented: $navigateToNextQuestion) {
                LearningCompletionView()
            }
        }
    }
}

#Preview("4") {
    NextQuestionView2()
}
