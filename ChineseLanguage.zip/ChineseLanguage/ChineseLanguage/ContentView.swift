//
//  ContentView.swift
//  ChineseLanguage
//
//  Created by Raghad on 27/03/1446 AH.
//

import SwiftUI
import AVFoundation

struct Practice: View {
    @State private var audioPlayer: AVAudioPlayer? // مشغل الصوت

       var body: some View {
           // الصورة التي تقوم بتشغيل الصوت عند الضغط عليها
           Image("yourImageName") // استبدل "yourImageName" باسم الصورة الخاصة بك
               .resizable() // لجعل الصورة قابلة للتغيير
               .scaledToFit() // لضبط حجم الصورة
               .frame(width: 300, height: 300) // ضبط الأبعاد حسب الحاجة
               .onTapGesture {
                   playSound() // تشغيل الصوت عند الضغط على الصورة
               }
       }

       // دالة لتحميل وتشغيل الصوت
       private func playSound() {
           guard let url = Bundle.main.url(forResource: "ppp", withExtension: "mp3") else {
               print("ملف الصوت غير موجود")
               return
           }

           do {
               audioPlayer = try AVAudioPlayer(contentsOf: url)
               audioPlayer?.play() // تشغيل الصوت
           } catch {
               print("خطأ في تشغيل الصوت: \(error)")
           }
       }
   }

#Preview {
    Practice()
}
