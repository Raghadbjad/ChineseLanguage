//
//  Level1.swift
//  ChineseLanguage
//
//  Created by Raghad on 28/03/1446 AH.
//

import SwiftUI
import AVFoundation

struct Level1: View {
    @State private var learningPage: Bool = false
    @State var userSelection: String
    
    var body: some View {
        NavigationView {
            ZStack {
                // الخلفية
                Image("LevelsBa")
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .ignoresSafeArea()

                VStack {
                    Spacer()
                    Text("المرحلة الأولى")
                        .font(.title)
                        .foregroundStyle(.black)
                        .shadow(radius: 10)

                    // صورة الولد أو البنت بناءً على الاختيار مع إمكانية التنقل عند الضغط
                    NavigationLink(destination: LearningView()) {
                        Image(userSelection == "boy" ? "Level1Boy" : "Level1Girl")
                            .resizable()
                            .scaledToFit()
                            .padding(.bottom, 0.0)
                    }
                }
                
                // زر العودة في الزاوية العلوية اليسرى
                VStack {
                    HStack {
                                          // NavigationLink للعودة إلى الصفحة الرئيسية
                                          NavigationLink(destination: HomePage()) { // قم بتغيير HomePage إلى اسم الصفحة الرئيسية لديك
                                              Image(systemName: "arrow.left")
                                                  .resizable()
                                                  .scaledToFit()
                                                  .frame(width: 30, height: 30)
                                                  .foregroundColor(.black) // لون السهم
                                          }
                        .padding()
                        Spacer()
                    }
                    Spacer()
                }
            }
            .navigationBarTitle("", displayMode: .inline) // عدم عرض عنوان في شريط التنقل
            .navigationBarHidden(true) // إخفاء شريط التنقل
        }
        .background(Color.black) // تغيير لون الخلفية للـ NavigationView إلى الأسود
    }
}

#Preview {
    Level1(userSelection: "girl")
}




struct FirstCard: View {
    
    @State private var audioPlayer: AVAudioPlayer?
    
    var body: some View {
        
        ZStack{
            
            Color("AccentColor")
                .ignoresSafeArea()// this to fill in all the backgroud
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            
            Image("one")
                .padding(.bottom, 400.0)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .onTapGesture {
                    playSound()
                }
            
            Image("Group")
                .resizable()
                .scaledToFit()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .clipShape(Circle())
                .frame(width:200.0)
                .padding(.bottom ,20.0)
                .onTapGesture {
                                   playSound() // تشغيل الصوت عند الضغط على صورة Group
                               }
            
            
            Image("Palm")
                .resizable()
                .scaledToFit()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .frame(width: 410, height: 220)
                .padding(.top, 491)
//                .padding(.top, 648.0)
            
            Text("واحد")
                .fontWeight(.bold)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(.top, 300)
                .foregroundColor(Color.black)
                .padding(.leading,190)
                .font(.system(size: 24))
            Text("One")
                .fontWeight(.bold)
                .padding(.top, 300)
                .foregroundColor(Color.black)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(.trailing,190)
                .font(.system(size: 24))
            
            
        }
        
    }
    
    private func playSound() {
        guard let url = Bundle.main.url(forResource: "Num1", withExtension: "mp3") else {
            print("ملف الصوت غير موجود")
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play() // تشغيل الصوت
        } catch {
            print("خطأ في تشغيل الصوت: \(error)")
        }
    }
    
}
    



#Preview ("LearningLevel1") {
    FirstCard()
}


struct SecondCard: View {
    @State private var audioPlayer: AVAudioPlayer?
         var body: some View {
             ZStack{
       
                  Color("AccentColor")
               .ignoresSafeArea()// this to fill in all the backgroud
                  
                  Image("Two")
                       .padding(.bottom, 400.0)
                  Image("GroupY")
                     .onTapGesture {
                         playSound()
                     }
                       
                  Image("Palm")
                       .resizable()
                       .scaledToFit()
                       .frame(width: 410, height: 220)
//                       .padding(.top, 648.0)
                       .padding(.top, 491)
//                       .padding(.top, 570)
                  
                  Text("إثنان")
                       .fontWeight(.bold)
                       .padding(.top, 300)
                       .foregroundColor(Color.black)
                       .padding(.leading,190)
                       .font(.system(size: 24))
                  Text("Two")
                       .fontWeight(.bold)
                       .foregroundColor(Color.black)
                       .padding(.top, 300)
                       .padding(.trailing,190)
                       .font(.system(size: 24))
                     
          
             }
            
         }
    private func playSound() {
        guard let url = Bundle.main.url(forResource: "Num2", withExtension: "mp3") else {
            print("ملف الصوت غير موجود")
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play() // تشغيل الصوت
        } catch {
            print("خطأ في تشغيل الصوت: \(error)")
        }
    }
     }

     #Preview {
          SecondCard()
     }


import SwiftUI

struct ThirdCard: View {
    @State private var audioPlayer: AVAudioPlayer?
    var body: some View {
        ZStack{
  
             Color("AccentColor")
          .ignoresSafeArea()// this to fill in all the backgroud
             
             Image("Num3")
                  .padding(.bottom, 400.0)
             Image("Three")
                .onTapGesture {
                    playSound()
                }
                  
             Image("Palm")
                  .resizable()
                  .scaledToFit()
                  .frame(width: 410, height: 220)
//                  .padding(.top, 648.0)
                  .padding(.top, 491)
//                  .padding(.top, 570)
             
             Text("ثلاثة")
                  .fontWeight(.bold)
                  .padding(.top, 300)
                  .foregroundColor(Color.black)
                  .padding(.leading,190)
                  .font(.system(size: 24))
             Text("Three")
                  .fontWeight(.bold)
                  .foregroundColor(Color.black)
                  .padding(.top, 300)
                  .padding(.trailing,190)
                  .font(.system(size: 24))
                
     
        }
       
    }
    private func playSound() {
        guard let url = Bundle.main.url(forResource: "Num3", withExtension: "mp3") else {
            print("ملف الصوت غير موجود")
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play() // تشغيل الصوت
        } catch {
            print("خطأ في تشغيل الصوت: \(error)")
        }
    }
}

#Preview {
     ThirdCard()
}


import SwiftUI

struct ForthCard: View {
    @State private var audioPlayer: AVAudioPlayer?
    var body: some View {
        ZStack{
  
             Color("AccentColor")
          .ignoresSafeArea()// this to fill in all the backgroud
             
             Image("I")
                  .padding(.bottom, 400.0)
             Image("Group3")
                .onTapGesture {
                    playSound()
                }
                  
             Image("Palm")
                  .resizable()
                  .scaledToFit()
                  .frame(width: 410, height: 220)
//                  .padding(.top, 648.0)
//                  .padding(.top, 570)
                  .padding(.top, 491)
             
             Text("أنا")
                  .fontWeight(.bold)
                  .padding(.top, 300)
                  .foregroundColor(Color.black)
                  .padding(.leading,190)
                  .font(.system(size: 24))
             Text("Me")
                  .fontWeight(.bold)
                  .foregroundColor(Color.black)
                  .padding(.top, 300)
                  .padding(.trailing,190)
                  .font(.system(size: 24))
                
     
        }
       
    }
    private func playSound() {
        guard let url = Bundle.main.url(forResource: "MeSound", withExtension: "mp3") else {
            print("ملف الصوت غير موجود")
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play() // تشغيل الصوت
        } catch {
            print("خطأ في تشغيل الصوت: \(error)")
        }
    }
}

#Preview ("4") {
     ForthCard()
}


import SwiftUI

struct FifthCard: View {
    @State private var audioPlayer: AVAudioPlayer?
    var body: some View {
        ZStack{
  
             Color("AccentColor")
          .ignoresSafeArea()// this to fill in all the backgroud
             
             Image("You")
                  .padding(.bottom, 400.0)
             Image("Group4")
                .onTapGesture {
                    playSound()
                }
                  
             Image("Palm")
                  .resizable()
                  .scaledToFit()
                  .frame(width: 410, height: 220)
//                  .padding(.top, 648.0)
//                  .padding(.top, 570)
                  .padding(.top, 491)
             
             Text("أنت")
                  .fontWeight(.bold)
                  .foregroundColor(Color.black)
                  .padding(.top, 300)
                  .padding(.leading,190)
                  .font(.system(size: 24))
             Text("You")
                  .fontWeight(.bold)
                  .foregroundColor(Color.black)
                  .padding(.top, 300)
                  .padding(.trailing,190)
                  .font(.system(size: 24))
                
     
        }
       
    }
    private func playSound() {
        guard let url = Bundle.main.url(forResource: "YouSound", withExtension: "mp3") else {
            print("ملف الصوت غير موجود")
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play() // تشغيل الصوت
        } catch {
            print("خطأ في تشغيل الصوت: \(error)")
        }
    }
}

#Preview {
     FifthCard()
}


struct SixthCard: View {
    @State private var audioPlayer: AVAudioPlayer?
    var body: some View {
        ZStack{
  
             Color("AccentColor")
          .ignoresSafeArea()// this to fill in all the backgroud
             
             Image("Sunday")
                  .padding(.bottom, 400.0)
             Image("GroupS")
                .onTapGesture {
                    playSound()
                }
                  
             Image("Palm")
                  .resizable()
                  .scaledToFit()
                  .frame(width: 410, height: 220)
//                  .padding(.top, 648.0)
                  .padding(.top, 491)
//                  .padding(.top, 570)
             
             Text("الأحد")
                  .fontWeight(.bold)
                  .foregroundColor(Color.black)
                  .padding(.top, 300)
                  .padding(.leading,190)
                  .font(.system(size: 24))
             Text("Sunday")
                  .fontWeight(.bold)
                  .foregroundColor(Color.black)
                  .padding(.top, 300)
                  .padding(.trailing,190)
                  .font(.system(size: 24))
                
     
        }
       
    }
    private func playSound() {
        guard let url = Bundle.main.url(forResource: "Sunday", withExtension: "mp3") else {
            print("ملف الصوت غير موجود")
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play() // تشغيل الصوت
        } catch {
            print("خطأ في تشغيل الصوت: \(error)")
        }
    }
}

#Preview {
     SixthCard()
}


import SwiftUI

struct SeventhCard: View {
    @State private var audioPlayer: AVAudioPlayer?
    var body: some View {
        ZStack{
  
             Color("AccentColor")
          .ignoresSafeArea()// this to fill in all the backgroud
             
             Image("Monday")
                  .padding(.bottom, 400.0)
             Image("GroupM")
                .onTapGesture {
                    playSound()
                }
                  
             Image("Palm")
                  .resizable()
                  .scaledToFit()
                  .frame(width: 410, height: 220)
//                  .padding(.top, 648.0)
                  .padding(.top, 491)
//                  .padding(.top, 570)
             
             Text("الإثنين")
                  .fontWeight(.bold)
                  .foregroundColor(Color.black)
                  .padding(.top, 300)
                  .padding(.leading,190)
                  .font(.system(size: 24))
             Text("Monday")
                  .fontWeight(.bold)
                  .foregroundColor(Color.black)
                  .padding(.top, 300)
                  .padding(.trailing,190)
                  .font(.system(size: 24))
                
     
        }
       
    }
    private func playSound() {
        guard let url = Bundle.main.url(forResource: "Monday", withExtension: "mp3") else {
            print("ملف الصوت غير موجود")
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play() // تشغيل الصوت
        } catch {
            print("خطأ في تشغيل الصوت: \(error)")
        }
    }
}

#Preview {
     SeventhCard()
}



struct TestPage : View {
    var body: some View {
        
        NavigationView {
            VStack{
                
                
            }
            
            
            NavigationLink(destination: Test()) {
                Text("ابدأ")  // نص الزر
                    .padding()
                    .font(.system(size: 27))
                    .frame(width: 80, height: 200.0)
                    .background(Color.white)
                    .foregroundColor(.black)
                    .clipShape(Circle())
                    .shadow(radius: 20)
                
                
                
                
                
            }
            
            
            
        }
    }
}
