//
//  ChineseLanguageApp.swift
//  ChineseLanguage
//
//  Created by Raghad on 27/03/1446 AH.
//

import SwiftUI

@main
struct ChineseLanguageApp: App {
    var body: some Scene {
        WindowGroup {
            HomePage()
//            Test()
            
        }
    }
}
