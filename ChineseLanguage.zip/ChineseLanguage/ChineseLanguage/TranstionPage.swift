//
//  TranstionPage.swift
//  ChineseLanguage
//
//  Created by Raghad on 02/04/1446 AH.
//

import SwiftUI

struct TranstionPage : View {
    @State private var showReadyPage = false
    @State private var showTestPage = false
    var body: some View {
        
//        NavigationView{
            
            ZStack {
                Color("AccentColor")
                    .ignoresSafeArea()
                
                Image("LastBa")
                     .resizable()
                     .scaledToFit()
                     .frame(width: 400, height: 331)
                     .padding(.top , 492)
                VStack{
                    
                    Button(action: {
                                       showTestPage = true
                                   }) {
                        Text(" جاهز للتحدي ؟ ")  // نص الزر
                            .font(.system(size: 24))
                            .bold()
                            .frame(width: 250, height: 50)
                            .background(Color.white)
                            .foregroundColor(.brown)
                            .font(.title)
                            .clipShape(Rectangle())
                            .cornerRadius(15)
                            .shadow(radius: 20)
                        
                    }  .fullScreenCover(isPresented: $showTestPage) {
                        Test() // الانتقال إلى صفحة Test
                    }
                   
                    
//                }
            }
        }
    }
}


#Preview {
    TranstionPage()
}





//struct LearningCompletionView: View {
//    @State private var showSecondImage = false
//    @State private var showCongratulationMessage = false
//
//    var body: some View {
//        ZStack {
//            Color("AccentColor")
//                .ignoresSafeArea()
//
//            VStack(spacing: 20) {
//                
//                // صورة الشخصية الأولى
//                Image("girl")
//                    .resizable()
//                    .aspectRatio(contentMode: .fit)
//                    .frame(width: 200, height: 200)
//                    .clipShape(Circle())
////                    .shadow(radius: 10)
////                    .opacity(showSecondImage ? 0 : 1)
////                    .scaleEffect(showSecondImage ? 0.8 : 1.0)
////                    .animation(.easeInOut(duration: 1), value: showSecondImage)
//
//                // صورة الشخصية الثانية
//                Image("FirstTranstionGirl")
//                    .resizable()
//                    .aspectRatio(contentMode: .fit)
//                    .frame(width: 200, height: 200)
//                    .clipShape(Circle())
//                    .shadow(radius: 10)
//                    .opacity(showSecondImage ? 1 : 0)
//                    .scaleEffect(showSecondImage ? 1.0 : 0.8)
//                    .animation(.easeInOut(duration: 1), value: showSecondImage)
//
//                // رسالة التهنئة
//                if showCongratulationMessage {
//                    Text("من عبق الأصالة إلى سحر التنوع!")
//                        .font(.headline)
//                        .foregroundColor(.black)
//                        .padding()
//                        .background(Color.white.opacity(0.8))
//                        .cornerRadius(10)
//                        .shadow(radius: 10)
//                        .transition(.slide)
//                        .animation(.easeInOut(duration: 1), value: showCongratulationMessage)
//                }
//
//                Spacer()
//
//
//            }
//        }
//        .onAppear {
//            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
//                showSecondImage.toggle()
//                showCongratulationMessage.toggle()
//            }
//        }
//    }
//}
