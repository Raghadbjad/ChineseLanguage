//
//  LearningView.swift
//  ChineseLanguage
//
//  Created by Raghad on 04/04/1446 AH.
//
import SwiftUI


struct LearningView: View {
    @State private var currentPage: Int = 0 // رقم الصفحة الحالية
    @State private var showReadyPage = false
    @Environment(\.presentationMode) var presentationMode // لإنهاء العرض الحالي
    
    var body: some View {
        ZStack {
            Color("AccentColor") // اختر اللون الذي تريده
                .edgesIgnoringSafeArea(.all)
            
            // استخدام TabView مع PageTabViewStyle لعرض الكلاسات ككاردز قابلة للسوايب
            TabView(selection: $currentPage) {
                FirstCard()
                    .tag(0)
                
                SecondCard()
                    .tag(1)
                
                ThirdCard()
                    .tag(2)
                
                ForthCard()
                    .tag(3)
                
                FifthCard()
                    .tag(4)
                
                SixthCard()
                    .tag(5)
                
                SeventhCard()
                    .tag(6)
                
                TranstionPage()
                    .tag(7)
            }
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never)) // تحويل العرض إلى نمط الصفحة القابلة للسوايب
            .frame(maxWidth: .infinity, maxHeight: .infinity) // جعل الكاردز تغطي الشاشة بالكامل
            .edgesIgnoringSafeArea(.all) // تجاهل حواف الشاشة
            
            // مؤشرات الصفحات
            VStack {
                Spacer() // تأكد من أن النقاط في الأسفل
                HStack {
                    ForEach(0..<8, id: \.self) { index in
                        Circle()
                            .fill(index == currentPage ? Color.black : Color.gray) // لون النقطة حسب الصفحة الحالية
                            .frame(width: 7, height: 7) // حجم النقطة
                            .padding(5)
                    }
                }
                .padding(.bottom, 20) // مسافة من الأسفل
                .cornerRadius(10) // زوايا مدورة للخلفية
                .padding() // Padding شامل
            }
            .frame(maxWidth: .infinity) // تأكد من أن HStack يملأ العرض بالكامل
            .padding(.bottom, 20) // تأكد من وجود مسافة كافية من الأسفل
            
            // زر بعلامة "X" في الزاوية العلوية اليسرى
            VStack {
//                HStack {
//                    Button(action: {
//                        // إغلاق الصفحة الحالية والعودة إلى Level1
//                        presentationMode.wrappedValue.dismiss()
//                    }) {
//                        Image(systemName: "xmark.circle.fill") // علامة X
//                            .resizable()
//                            .foregroundColor(.black)
//                            .frame(width: 30, height: 30)
//                            .padding()
//                    }
//                    
//                    Spacer()
//                }
                Spacer()
            }
        }
    }
}

#Preview ("LearningView") {
    LearningView()
}
