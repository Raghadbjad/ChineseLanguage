


import SwiftUI

struct CharacterPage: View {
    @State private var selectedCharacter: String? // متغير لتحديد الشخصية المختارة

    var body: some View {
        NavigationStack {
            ZStack {
                // الخلفية
                Image("HideBa")
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .ignoresSafeArea()

                VStack {
                    Text("أختار شخصيتك : ")
                        .foregroundColor(.white)
                        .font(.title)
                        .padding()

                    Spacer().frame(height: 50)

                    HStack {
                        // صورة الولد
                        VStack {
                            // وضع NavigationLink حول صورة الولد
                            NavigationLink(destination: UserPage(userSelection: "boy")) {
                                Image("boy")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 137, height: 137)
                                    .overlay(
                                        // إضافة إطار عند اختيار الولد
                                        selectedCharacter == "boy" ? Circle().stroke(Color.white, lineWidth: 4) : nil
                                    )
                            }

                            Text("男孩")
                                .foregroundColor(.white)
                                .font(.title)
                        }
                        .padding(28.0)
                        .onTapGesture {
                            selectedCharacter = "boy" // تحديد الشخصية المختارة
                        }

                        // صورة البنت
                        VStack {
                            // وضع NavigationLink حول صورة البنت
                            NavigationLink(destination: UserPage(userSelection: "girl")) {
                                Image("girl")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 137, height: 137)
                                    .overlay(
                                        // إضافة إطار عند اختيار البنت
                                        selectedCharacter == "girl" ? Circle().stroke(Color.white, lineWidth: 4) : nil
                                    )
                            }

                            Text("女孩")
                                .foregroundColor(.white)
                                .font(.title)
                        }
                        .padding(28.0)
                        .onTapGesture {
                            selectedCharacter = "girl" // تحديد الشخصية المختارة
                        }
                    }
                    .padding()

                    Spacer().frame(height: 150)
                }
            }
        }
    }
}

#Preview("Character") {
    CharacterPage()
}
