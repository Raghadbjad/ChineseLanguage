//
//  HomePage.swift
//  ChineseLanguage
//
//  Created by Raghad on 04/04/1446 AH.
//

//import SwiftUI
//import AVFoundation
//
//struct HomePage: View {
//    @State private var navigateToCharacter = false // التحكم في التنقل إلى CharacterPage
//    @State private var navigateToProfile = false // التحكم في التنقل إلى ProfilePage
//    @State private var navigateToCompletion = false // التحكم في التنقل إلى LearningCompletionView
//    @State private var audioPlayer: AVAudioPlayer?
//    @State private var hasPlayedSound = false // التحكم في تشغيل الصوت مرة واحدة
//    
//    // متغيرات للتحقق من نوع المستخدم
//    @AppStorage("userGender") private var userGender: String? // يمكن أن تكون "ذكر" أو "أنثى"
//    @AppStorage("hasVisitedBefore") private var hasVisitedBefore = false // للتحقق إذا كان المستخدم قد زار التطبيق من قبل
//    @AppStorage("userPassedLevel1") private var userPassedLevel1: Bool = false // حالة اجتياز المستوى
//
//    var body: some View {
//        NavigationView {
//            ZStack {
//                Image("Front")
//                    .resizable()
//                    .scaledToFit()
//                    .frame(maxWidth: .infinity, maxHeight: .infinity)
//                    .ignoresSafeArea()
//
//                VStack {
//                    VStack {
//                        Text("你好")
//                            .font(.system(size: 50))
//                            .fontWeight(.bold)
//                            .padding(.bottom, 20.0)
//                        
//                        Text("مرحبًا بك!")
//                            .font(.system(size: 50))
//                            .fontWeight(.regular)
//                            .foregroundColor(Color.black)
//                            .multilineTextAlignment(.center)
//                    }
//                    .padding(.bottom, 70.0)
//                    .padding(.top, 80.0)
//                    
//                    VStack {
//                        Text("العالم بإنتظارك..")
//                            .font(.system(size: 45))
//                            .fontWeight(.regular)
//                            .foregroundColor(Color.black)
//                            .multilineTextAlignment(.center)
//                            .padding(.bottom, 90.0)
//                    }
//                }
//                .onAppear {
//                    checkUserStatus()
//                    
//                    if !hasPlayedSound {
//                        playSound()
//                        hasPlayedSound = true // تحديث الحالة بعد تشغيل الصوت
//                    }
//                }
//                .onTapGesture {
//                    navigateToCharacter = true // تفعيل التنقل عند الضغط على الشاشة
//                }
//
//                // روابط التنقل
//                NavigationLink(destination: CharacterPage(), isActive: $navigateToCharacter) {
//                    EmptyView() // التنقل إلى CharacterPage عند الضغط
//                }
//                NavigationLink(destination: LearningCompletionView(userPassedLevel1: $userPassedLevel1), isActive: $navigateToProfile) {
//                    EmptyView() // التنقل إلى ProfilePage إذا كان قد زار التطبيق سابقًا
//                }
//                NavigationLink(destination: LearningCompletionView(userPassedLevel1: $userPassedLevel1), isActive: $navigateToCompletion) {
//                    EmptyView() // التنقل إلى LearningCompletionView
//                }
//            }
//        }
//    }
//    
//    private func playSound() {
//        guard let url = Bundle.main.url(forResource: "HelloSaound", withExtension: "m4a") else {
//            print("ملف الصوت غير موجود")
//            return
//        }
//
//        do {
//            audioPlayer = try AVAudioPlayer(contentsOf: url)
//            audioPlayer?.play() // تشغيل الصوت
//        } catch {
//            print("خطأ في تشغيل الصوت: \(error)")
//        }
//    }
//    
//    private func checkUserStatus() {
//        // هنا يمكنك استخدام UserDefaults أو أي طريقة أخرى لحفظ حالة المستخدم
//        if hasVisitedBefore {
//            // إذا كان قد زار التطبيق سابقًا، تحقق من نوع المستخدم
//            navigateToProfile = true // التنقل إلى صفحة البروفايل مباشرة
//        } else {
//            // إذا كان أول مرة يدخل، اتركه هنا
//            hasVisitedBefore = true // تحديث الحالة
//            // هنا يمكنك السماح له باختيار نوع المستخدم (ذكر أو أنثى)
//            // يمكنك استخدام Popup أو NavigationLink إلى صفحة اختيار النوع
//        }
//    }
//}


import SwiftUI
import AVFoundation

struct HomePage: View {
    @State private var navigateToCharacter = false // التحكم في التنقل إلى CharacterPage
    @State private var audioPlayer: AVAudioPlayer?
    @State private var hasPlayedSound = false // التحكم في تشغيل الصوت مرة واحدة

    var body: some View {
        NavigationView {
            ZStack {
                Image("Front")
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .ignoresSafeArea()

                VStack {
                    VStack {
                        Text("你好")
                            .font(.system(size: 50))
                            .fontWeight(.bold)
                            .foregroundColor(Color.black)
                            .padding(.bottom, 20.0)
                        
                        Text("مرحبًا بك!")
                            .font(.system(size: 50))
                            .fontWeight(.regular)
                            .foregroundColor(Color.black)
                            .multilineTextAlignment(.center)
                    }
                    .padding(.bottom, 70.0)
                    .padding(.top, 80.0)
                    
                    VStack {
                        Text("العالم بإنتظارك..")
                            .font(.system(size: 45))
                            .fontWeight(.regular)
                            .foregroundColor(Color.black)
                            .multilineTextAlignment(.center)
                            .padding(.bottom, 90.0)
                    }
                }
                .onAppear {
                    if !hasPlayedSound {
                        playSound()
                        hasPlayedSound = true // تحديث الحالة بعد تشغيل الصوت
                    }
                }
                .onTapGesture {
                    navigateToCharacter = true // تفعيل التنقل عند الضغط على الشاشة
                }

                // روابط التنقل
                NavigationLink(destination: CharacterPage(), isActive: $navigateToCharacter) {
                    EmptyView() // التنقل إلى CharacterPage عند الضغط
                }
               
            }
        }
    }
    
    private func playSound() {
        guard let url = Bundle.main.url(forResource: "HelloSaound", withExtension: "m4a") else {
            print("ملف الصوت غير موجود")
            return
        }

        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play() // تشغيل الصوت
        } catch {
            print("خطأ في تشغيل الصوت: \(error)")
        }
    }
 
}
#Preview {
    HomePage()
}
