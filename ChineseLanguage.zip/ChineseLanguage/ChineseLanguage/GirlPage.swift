////
////  GirlPage.swift
////  ChineseLanguage
////
////  Created by Raghad on 27/03/1446 AH.
////
//
//import SwiftUI
//
//import SwiftUI
//
//struct GirlPage: View {
//    // عدد الصفحات
//    let pages = ["page1", "page2", "page3"]
//    
//    // المتغير لتتبع الصفحة الحالية
//    @State private var currentPage = 0
//    
//    var body: some View {
//        VStack {
//            // عرض الصور مع السحب
//            TabView(selection: $currentPage) {
//                ForEach(0..<pages.count, id: \.self) { index in
//                    Image(pages[index])
//                        .resizable()
//                        .scaledToFit()
//                        .tag(index) // تحديد كل صفحة باستخدام tag لتتبع الصفحة الحالية
//                }
//            }
//            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always)) // إضافة النقاط أسفل الشاشة
//            .frame(height: 700) // يمكنك تخصيص هذا الحجم بناءً على متطلباتك
//            
//            // النقاط المؤشرة
//            HStack {
//                ForEach(0..<pages.count, id: \.self) { index in
//                    Circle()
//                        .fill(index == currentPage ? Color.blue : Color.gray) // تمييز النقطة الحالية
//                        .frame(width: 10, height: 10)
//                }
//            }
//            .padding()
//        }
//    }
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        GirlPage()
//    }
//}
//
//
//
//#Preview {
//    GirlPage()
//}
