//
//  BoyPage.swift
//  ChineseLanguage
//
//  Created by Raghad on 27/03/1446 AH.
//

//import SwiftUI
//
//struct UserPage: View {
//    @State private var userName: String = "" // حفظ اسم المستخدم
//    @AppStorage("userCharacter") private var userCharacter: String = "" // حفظ نوع الشخصية
//    @State private var navigateToLevel1: Bool = false // حالة لتحديد الانتقال إلى Level 1
//    let userSelection: String // النوع المختار (ولد أو بنت)
//    
//    var body: some View {
//        //        NavigationView {
//        ZStack {
//            Image("HideBa") // الخلفية
//                .resizable()
//                .scaledToFill()
//                .frame(maxWidth: .infinity, maxHeight: .infinity)
//                .ignoresSafeArea()
//            
//            VStack {
//                Text("أدخل اسمك : ")
//                    .foregroundColor(.white)
//                    .font(.title)
//                    .padding()
//                
//                Image(userSelection == "boy" ? "boy" : "girl") // صورة الولد أو البنت
//                    .resizable()
//                    .scaledToFit()
//                    .padding()
//                    .offset(x: 13)
//                
//                TextField("你的名字", text: $userName) // حقل نص لإدخال اسم المستخدم
//                    .textInputAutocapitalization(.never) // بدون حروف كبيرة
//                    .multilineTextAlignment(.center) // محاذاة النص في المنتصف
//                    .disableAutocorrection(true) // تعطيل التصحيح التلقائي
//                    .frame(width: 300, height: 30.0)
//                    .textFieldStyle(.roundedBorder) // تحسين شكل الحقل النصي
//                    .padding()
//                
//                
//                // زر لبدء اللعبة
//                Button(action: {
//                    
//                    userCharacter = userSelection // حفظ نوع الشخصية
//                    navigateToLevel1 = true // الانتقال إلى Level 1
//                }
//                ) {
//                    Text("ابدأ") // نص الزر
//                        .padding()
//                        .font(.system(size: 27))
//                        .frame(width: 80, height: 200.0)
//                        .background(Color.white)
//                        .foregroundColor(.black)
//                        .clipShape(Circle())
//                        .shadow(radius: 20)
//                }
//                .background(
//                    NavigationLink(destination: Level1(userSelection: userSelection), isActive: $navigateToLevel1) {
//                        EmptyView() // لا تظهر هذه المرة
//                    }
//                )
//            }
//        }
//    }
//  
//}
//#Preview {
//    UserPage(userSelection: "boy")
//}


import SwiftUI

struct UserPage: View {
    @State private var userName: String = "" // حفظ اسم المستخدم
    @AppStorage("userCharacter") private var userCharacter: String = "" // حفظ نوع الشخصية
    @State private var navigateToLevel1: Bool = false // حالة لتحديد الانتقال إلى Level 1
    let userSelection: String // النوع المختار (ولد أو بنت)
    
    var body: some View {
        ZStack {
            Image("HideBa") // الخلفية
                .resizable()
                .scaledToFill()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .ignoresSafeArea()
            
            VStack {
                Text("أدخل اسمك : ")
                    .foregroundColor(.white)
                    .font(.title)
                    .padding()
                
                Image(userSelection == "boy" ? "boy" : "girl") // صورة الولد أو البنت
                    .resizable()
                    .scaledToFit()
                    .padding()
                    .offset(x: 13)
                
                TextField("你的名字", text: $userName) // حقل نص لإدخال اسم المستخدم
                    .textInputAutocapitalization(.never) // بدون حروف كبيرة
                    .multilineTextAlignment(.center) // محاذاة النص في المنتصف
                    .disableAutocorrection(true) // تعطيل التصحيح التلقائي
                    .frame(width: 300, height: 30.0)
                    .textFieldStyle(.roundedBorder) // تحسين شكل الحقل النصي
                    .padding()
                
                // زر لبدء اللعبة
                Button(action: {
                    userCharacter = userSelection // حفظ نوع الشخصية
                    navigateToLevel1 = true // الانتقال إلى Level 1
                }) {
                    Text("ابدأ") // نص الزر
                        .padding()
                        .font(.system(size: 27))
                        .frame(width: 80, height: 200.0)
                        .background(Color.white)
                        .foregroundColor(.black)
                        .clipShape(Circle())
                        .shadow(radius: 20)
                }
                .background(
                    NavigationLink(destination: Level1(userSelection: userSelection), isActive: $navigateToLevel1) {
                        EmptyView() // لا تظهر هذه المرة
                    }
                )
            }
        }
        .navigationBarBackButtonHidden(true) // إخفاء زر الرجوع الافتراضي
        // زر الرجوع المخصص
    }
}
    
//    // زر الرجوع المخصص بدون كلمة "Back"
//    var backButton: some View {
//        Button(action: {
//            // العودة إلى الشاشة السابقة
//            navigateToLevel1 = false
//        }) {
//            Image(systemName: "chevron.backward") // فقط سهم الرجوع
//                .foregroundColor(.black) // لون السهم
//                .font(.system(size: 20)) // حجم السهم
//        }
//    }
//}

#Preview {
    UserPage(userSelection: "boy")
}




//TapView
