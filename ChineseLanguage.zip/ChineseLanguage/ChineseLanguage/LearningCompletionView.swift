//
//  LearningCompletionView.swift
//  ChineseLanguage
//
//  Created by Raghad on 05/04/1446 AH.
//

import SwiftUI
//
//struct LearningCompletionView: View {
//    
//    @State private var progress: Float = 0.0 // القيمة الابتدائية للتقدم 0
//    @State private var isLevelCompleted = false // للتحكم في إظهار الصورة الجديدة
//    @AppStorage("userCharacter") private var userCharacter: String = "" // نوع المستخدم (ولد أو بنت)
//    
//    var body: some View {
//        ZStack {
//            Color("AccentColor")
//                .ignoresSafeArea()
//            
//            VStack(spacing: 20) {
//                
//                // المجموعة العلوية من الصور
//                HStack(spacing: -25) {
//                    if userCharacter == "boy" {
//                        Image("ClothesBoy")
//                            .resizable()
//                            .scaledToFit()
//                            .frame(width: 100, height: 100) // صورة الولد
//                            .padding(.top, -25)
//                        Image("sticks")
//                            .resizable()
//                            .scaledToFit()
//                            .frame(width: 120, height: 120)
//                            .opacity(0.5)
//                        Image("fan")
//                            .resizable()
//                            .scaledToFit()
//                            .frame(width: 120, height: 120)
//                            .opacity(0.5)
//                        Image("hat")
//                            .resizable()
//                            .scaledToFit()
//                            .frame(width: 140, height: 140)
//                            .opacity(0.5)
//                    } else {
//                        Image("ClothesGirl")
//                            .resizable()
//                            .scaledToFit()
//                            .frame(width: 100, height: 100) // صورة البنت
//                            .padding(.top, -25)
//                        Image("sticks")
//                            .resizable()
//                            .scaledToFit()
//                            .frame(width: 120, height: 120)
//                            .opacity(0.5)
//                        Image("fan")
//                            .resizable()
//                            .scaledToFit()
//                            .frame(width: 120, height: 120)
//                            .opacity(0.5)
//                        Image("hat")
//                            .resizable()
//                            .scaledToFit()
//                            .frame(width: 140, height: 140)
//                            .opacity(0.5)
//                    }
//                }
//                
//                // صورة الفتاة أو الولد بناءً على اختيار المستخدم مع أنيميشن عند الانتقال
//                ZStack {
//                    if isLevelCompleted {
//                        if userCharacter == "boy" {
//                            Image("FirstTranstionBoy") // صورة الولد بعد إكمال المرحلة
//                                .resizable()
//                                .scaledToFit()
//                                .frame(width: 300, height: 300)
//                                .padding(.bottom, 50)
//                                .transition(.opacity) // إضافة تأثير ظهور واختفاء
//                        } else {
//                            Image("FirstTranstionGirl") // صورة البنت بعد إكمال المرحلة
//                                .resizable()
//                                .scaledToFit()
//                                .frame(width: 300, height: 300)
//                                .padding(.bottom, 50)
//                                .transition(.opacity) // إضافة تأثير ظهور واختفاء
//                        }
//                    } else {
//                        if userCharacter == "boy" {
//                            Image("boy") // صورة الولد في بداية المرحلة
//                                .resizable()
//                                .scaledToFit()
//                                .frame(width: 300, height: 300)
//                                .padding(.bottom, 50)
//                                .transition(.opacity) // إضافة تأثير ظهور واختفاء
//                        } else {
//                            Image("girl") // صورة البنت في بداية المرحلة
//                                .resizable()
//                                .scaledToFit()
//                                .frame(width: 300, height: 300)
//                                .padding(.bottom, 50)
//                                .transition(.opacity) // إضافة تأثير ظهور واختفاء
//                        }
//                    }
//                }
//                .animation(.easeInOut(duration: 0.5), value: isLevelCompleted) // أنيميشن
//                
//                // Progress Bar مع رقم التقدم
//                VStack {
//                    ProgressView(value: progress, total: 1.0)
//                        .progressViewStyle(LinearProgressViewStyle(tint: .green))
//                        .padding(.horizontal)
//                        .scaleEffect(x: 1, y: 4, anchor: .center) // تعديل حجم شريط التقدم
//                    
//                    Text("\(Int(progress * 100))%")
//                        .font(.title2)
//                        .fontWeight(.bold)
//                        .foregroundColor(.black)
//                }
//                
//                // زر تحديث التقدم
//                Button(action: {
//                    withAnimation {
//                        if progress < 0.2 { // تعديل لزيادة التقدم حتى 20% فقط
//                            progress += 0.2 // زيادة التقدم بمقدار 20%
//                            
//                            if progress >= 0.2 {
//                                isLevelCompleted = true // إظهار الصورة الجديدة عند الوصول إلى 20%
//                            }
//                        }
//                    }
//                }) {
//                    Text("تم إكمال المرحلة الثانية")
//                        .font(.headline)
//                        .fontWeight(.bold)
//                        .foregroundColor(.brown)
//                        .padding()
//                        .frame(maxWidth: .infinity) // الزر بعرض كامل
//                        .background(Color.white)
//                        .cornerRadius(15)
//                        .shadow(color: .black.opacity(0.3), radius: 10, x: 5, y: 5)
//                }
//                .padding(.horizontal)
//                .padding(.bottom, 40)
//                .disabled(progress >= 0.2) // تعطيل الزر عند الوصول إلى 20%
//            }
//        }
//    }
//}
//
//#Preview {
//    LearningCompletionView()
//}


struct LearningCompletionView: View {
    
    @State private var progress: Float = 0.0 // القيمة الابتدائية للتقدم 0
    @State private var isLevelCompleted = false // للتحكم في إظهار الصورة الجديدة
    @AppStorage("userCharacter") private var userCharacter: String = "" // نوع المستخدم (ولد أو بنت)
    @State private var navigateToHome: Bool = false // حالة للتوجه إلى صفحة الـ Home
    
    var body: some View {
        ZStack {
            Color("AccentColor")
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                
                // زر العودة إلى الصفحة الرئيسية في الزاوية العليا اليسرى
                HStack {
                    Button(action: {
                        navigateToHome = true // تفعيل الانتقال إلى الصفحة الرئيسية
                    }) {
                        Image(systemName: "house.fill") // أيقونة الصفحة الرئيسية
                            .resizable()
                            .scaledToFit()
                            .frame(width: 40, height: 40) // حجم الأيقونة
                            .foregroundColor(.black) // لون الأيقونة إلى الأسود
                            .padding() // إضافة مساحة حول الأيقونة
                    }
                    .padding(.leading) // إضافة مساحة من اليسار
                    .padding(.top) // إضافة مساحة من الأعلى
                    
                    Spacer() // لإضافة مساحة مرنة بين الأيقونة وبقية العناصر
                }

                // المجموعة العلوية من الصور
                HStack(spacing: -25) {
                    if userCharacter == "boy" {
                        Image("ClothesBoy")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100) // صورة الولد
                            .padding(.top, -25)
                        Image("sticks")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 120)
                            .opacity(0.5)
                        Image("fan")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 120)
                            .opacity(0.5)
                        Image("hat")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 140, height: 140)
                            .opacity(0.5)
                    } else {
                        Image("ClothesGirl")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100) // صورة البنت
                            .padding(.top, -25)
                        Image("sticks")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 120)
                            .opacity(0.5)
                        Image("fan")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 120)
                            .opacity(0.5)
                        Image("hat")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 140, height: 140)
                            .opacity(0.5)
                    }
                }
                
                // صورة الفتاة أو الولد بناءً على اختيار المستخدم مع أنيميشن عند الانتقال
                ZStack {
                    if isLevelCompleted {
                        if userCharacter == "boy" {
                            Image("FirstTranstionBoy") // صورة الولد بعد إكمال المرحلة
                                .resizable()
                                .scaledToFit()
                                .frame(width: 300, height: 300)
                                .padding(.bottom, 50)
                                .transition(.opacity) // إضافة تأثير ظهور واختفاء
                        } else {
                            Image("FirstTranstionGirl") // صورة البنت بعد إكمال المرحلة
                                .resizable()
                                .scaledToFit()
                                .frame(width: 300, height: 300)
                                .padding(.bottom, 50)
                                .transition(.opacity) // إضافة تأثير ظهور واختفاء
                        }
                    } else {
                        if userCharacter == "boy" {
                            Image("boy") // صورة الولد في بداية المرحلة
                                .resizable()
                                .scaledToFit()
                                .frame(width: 300, height: 300)
                                .padding(.bottom, 50)
                                .transition(.opacity) // إضافة تأثير ظهور واختفاء
                        } else {
                            Image("girl") // صورة البنت في بداية المرحلة
                                .resizable()
                                .scaledToFit()
                                .frame(width: 300, height: 300)
                                .padding(.bottom, 50)
                                .transition(.opacity) // إضافة تأثير ظهور واختفاء
                        }
                    }
                }
                .animation(.easeInOut(duration: 0.5), value: isLevelCompleted) // أنيميشن
                
                // Progress Bar مع رقم التقدم
                VStack {
                    ProgressView(value: progress, total: 1.0)
                        .progressViewStyle(LinearProgressViewStyle(tint: .green))
                        .padding(.horizontal)
                        .scaleEffect(x: 1, y: 4, anchor: .center) // تعديل حجم شريط التقدم
                    
                    Text("\(Int(progress * 100))%")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                }
                
                // زر تحديث التقدم
                Button(action: {
                    withAnimation {
                        if progress < 0.2 { // تعديل لزيادة التقدم حتى 20% فقط
                            progress += 0.2 // زيادة التقدم بمقدار 20%
                            
                            if progress >= 0.2 {
                                isLevelCompleted = true // إظهار الصورة الجديدة عند الوصول إلى 20%
                            }
                        }
                    }
                }) {
                    Text("تم إكمال المرحلة الثانية")
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(.brown)
                        .padding()
                        .frame(maxWidth: .infinity) // الزر بعرض كامل
                        .background(Color.white)
                        .cornerRadius(15)
                        .shadow(color: .black.opacity(0.3), radius: 10, x: 5, y: 5)
                }
                .padding(.horizontal)
                .padding(.bottom, 40)
                .disabled(progress >= 0.2) // تعطيل الزر عند الوصول إلى 20%
                
                // NavigationLink للانتقال إلى الصفحة الرئيسية
                NavigationLink(destination: HomePage(), isActive: $navigateToHome) {
                    EmptyView() // الانتقال إلى الصفحة الرئيسية
                }
            }
        }
    }
}

#Preview {
    LearningCompletionView()
}
